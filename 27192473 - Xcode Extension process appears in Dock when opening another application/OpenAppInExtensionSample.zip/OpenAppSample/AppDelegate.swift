//
//  AppDelegate.swift
//  OpenAppSample
//
//  Created by Ashton Williams on 23/06/2016.
//  Copyright © 2016 Ashton-W. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

}

